from pathlib import Path
import csv, datetime, gzip, hashlib, html, json, re, shutil, sys
from urllib.parse import quote
from html.parser import HTMLParser

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROJECT = ROOT.parent
ARCHIVE = PROJECT / 'docs/실험 결과/실제 판례 24건 스트레스 검토'
sys.path.insert(0, str(HERE))
from easy_cases import CASES

BASE = ROOT / '.검토_기준'
RAW = BASE / '원본'
RAW.mkdir(exist_ok=True)
rows = {r['ID']: r for r in csv.DictReader((ARCHIVE/'02_24건_대입결과.csv').open(encoding='utf-8-sig'))}
snap = json.loads((BASE/'작성시점.json').read_text())
STAMP = snap['created_at']

ISSUES = {
 'D01': ('79개 재료와 대응표가 맞나요?', '아니오', '본문은 79개인데 상세 대응표는 77개로 적혀 있습니다. 「못 찾음·없음 구분」과 「보고 주체 확인」이 빠진 대응표를 맞춰야 합니다. 두 재료 자체는 정의 문서에 이미 있습니다.', [('materials.md',48),('전문가 에이전트 정의 2.md',1117)]),
 'D02': ('목표가 그대로면 새 증거 확인을 건너뛰어도 되나요?', '아니오', '큰 순서도에는 목표·범위가 안 바뀌면 바로 대안 판단으로 가는 길이 있습니다. 새 증거·법리·권한이 바뀌었는지도 먼저 보고, 필요한 자료 확인과 관련 결과의 재검사로 연결해야 합니다. 이 책임 자체는 「현재 진행 상태」에 이미 있습니다.', [('전문가 에이전트 정의.md',660),('전문가 에이전트 정의 2.md',3605)]),
 'D03': ('사용자가 직접 요청한 긴급 업무도 긴급도 판단이 필요한가요?', '예', '큰 순서도는 신호 입력에서 긴급 판단으로 이어지지만 사용자 요청은 다른 길로 갑니다. 입력 경로와 관계없이 임박한 기한과 즉시 막을 피해를 확인하도록 맞춰야 합니다. 긴급하다는 이유로 권한을 넓히지는 않습니다.', [('전문가 에이전트 정의.md',590)]),
 'D04': ('실행 결과를 성공과 실패 두 개로만 나눠도 되나요?', '아니오', '큰 순서도에는 실패 여부의 두 갈래가 남아 있습니다. 상세 정의에 이미 있는 일부 성공·결과 불명을 연결해야 합니다. 처리 여부를 모르면 원래 요청부터 조회하고, 확인 전에는 다시 실행하지 않습니다.', [('전문가 에이전트 정의.md',690),('전문가 에이전트 정의 2.md',6458)]),
 'D05': ('답변을 기다리는 것만 적으면 후속 처리가 충분한가요?', '아니오', '기다릴 기한·담당·깨울 조건·답이 없을 때의 다음 행동이 필요합니다. 「대기·후속 관리」에 이미 있는 조건을 큰 순서도의 답변 대기에도 연결해야 합니다.', [('전문가 에이전트 정의.md',639),('전문가 에이전트 정의 2.md',5480)]),
 'D06': ('사람에게 일부를 넘겼으면 같은 건의 모든 작업을 멈춰야 하나요?', '아니오', '본문은 영향받지 않는 작업을 계속하라고 합니다. 그런데 시험표는 그 건의 이후 도구 호출을 전부 0건으로 요구합니다. 보류 대상만 막고, 허용된 독립 작업과 상태 확인은 이어 갈 수 있도록 시험 조건을 맞춰야 합니다.', [('전문가 에이전트 정의 2.md',5122),('전문가 에이전트 정의 2.md',5153)]),
 'D07': ('필수 검사를 못 했어도 확신도만 낮추고 통과해도 되나요?', '아니오', '상세 본문은 필수 검사 불가를 통과시키지 말라고 합니다. 검증 순서도에는 검사 못 함에서 채점으로 넘어가는 길이 남아 있습니다. 필수 검사인지 나누고, 필요한 자료 확보·대체 검사·미완료 처리로 이어야 합니다.', [('전문가 에이전트 정의 2.md',7056),('전문가 에이전트 정의 2.md',7292)]),
 'D08': ('바뀐 옛 판례를 모든 상황에서 근거로 쓰지 못하게 막아도 되나요?', '아니오', '「적용 사례」의 설명·시험표는 뒤집힌 해석을 근거로 쓴 수를 0건으로 요구합니다. 통상임금처럼 종전 법리를 적용해야 할 범위가 남는 경우를 구분해야 합니다. 해당 시점·쟁점에 적용할 수 없는 법리를 막도록 조건을 구체화해야 합니다.', [('전문가 에이전트 정의 2.md',2981),('전문가 에이전트 정의 2.md',3001)])
}

class TextReader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag.lower() in ['br','p','div','li','tr']: self.parts.append('\n')
        if tag.lower()=='img':
            src=dict(attrs).get('src','')
            if src!='/LSA/flDownload.do?flSeq=36958970':raise ValueError('미처리 이미지: '+src)
            self.parts.append('⟦원문이미지36958970⟧')
    def handle_endtag(self, tag):
        if tag.lower() in ['p','div','li','tr']: self.parts.append('\n')
    def handle_data(self, data): self.parts.append(data)

def plain(value):
    p=TextReader();p.feed(str(value or ''));p.close()
    return ''.join(p.parts).replace('\r\n','\n').replace('\r','\n')

def norm(value): return re.sub(r'\s+','',value)
def digest(value):return hashlib.sha256(value).hexdigest()
def link(path):return quote(str(path),safe='/#')
def slug(value):return re.sub(r'[^0-9A-Za-z가-힣]+','_',value).strip('_')
def object_particle(value):
    last=ord(value[-1]);return '을' if 0xAC00<=last<=0xD7A3 and (last-0xAC00)%28 else '를'
def question(task):
    if task.endswith('나눔'): return task[:-2]+'나눴나요?'
    if task.endswith('읽음'): return task[:-2]+'읽었나요?'
    return task+'했나요?'
def finish_document(out):
    text='\n\n'.join(out)+'\n'
    # 표의 행 사이는 빈 줄을 넣지 않는다.
    return re.sub(r'(?m)(\|[^\n]*\|)\n\n(?=\|)',r'\1\n',text)
def escaped(s):
    # 화면에서 원문 문자가 Markdown 문법으로 사라지지 않게 한다.
    return re.sub(r'([\\`*_[\]<>|])',r'\\\1',s)
def render(value):
    src=plain(value)
    # 원래 있던 줄바꿈을 문단으로 표시한다. 단어·구두점·숫자는 바꾸지 않는다.
    chunks=[re.sub(r'[\t \u00a0]+',' ',x).strip() for x in src.split('\n') if x.strip()]
    parts=[]
    for c in chunks:
        if re.fullmatch(r'【[^】]+】',c):parts.append('#### '+escaped(c))
        else:
            # 문단 첫 숫자가 자동 목록으로 변하지 않게 보존한다.
            c=escaped(c)
            c=re.sub(r'^(\d+)([.)])',lambda m:m[1]+'\\'+m[2],c)
            c=re.sub(r'^([#>+\-])(?=\s)',r'\\\1',c)
            parts.append(c)
    result='\n\n'.join(parts)
    return result.replace('⟦원문이미지36958970⟧','![출원 표장 원본](.검토_기준/원본/198440_표장.png)')

def source_load(r):
    sid=Path(r['원본경로']).name.split('_')[0]
    src=ARCHIVE/'재현/원본'/f'{sid}.json.gz'
    data=gzip.decompress(src.read_bytes())
    assert digest(data)==r['원본SHA256'], (r['ID'],'보관 원본 지문 불일치')
    shutil.copyfile(src,RAW/src.name)
    doc=json.loads(data)['PrecService']
    assert doc['사건번호']==r['사건번호']
    return sid,doc,data

def original_sections(doc, prefix=''):
    fields=[('판시사항','issues','법원이 판단한 질문'),('판결요지','summary','판단 이유의 요지'),('참조조문','statutes','참조조문'),('참조판례','references','참조판례'),('판례내용','fulltext','판결 전문 — 주문·이유·각 의견')]
    out=[]
    for key,anchor,title in fields:
        out += [f'<a id="{prefix}{anchor}"></a>',f'### {title}',
                f'<!-- 원문시작:{prefix}{key} -->', render(doc.get(key,'')) or '해당 필드에 내용이 없습니다.',f'<!-- 원문끝:{prefix}{key} -->']
    return '\n\n'.join(out)

def original_note(rid):
    base='보관된 JSON의 판시사항·판결요지·참조조문·참조판례·판례내용을 모두 옮겼습니다. 아래 원문은 쉬운 말로 고치거나 요약하지 않았고, 제목과 줄바꿈 등 읽는 형식만 정리했습니다. 다수의견뿐 아니라 원본에 들어 있는 다른 의견도 그대로 남겼습니다.'
    base+=' 원본에 없는 소송기록·별지·이미지는 새로 만들어 넣지 않았습니다. 이는 보관된 텍스트의 전문이며, 사건의 증거기록 전부를 확보했다는 뜻은 아닙니다.'
    if rid=='C24':base+=' **본문·판결요지의 표장 자리는 빈칸이지만 판시사항에는 이미지 주소가 있었습니다. 이번에 같은 파일 번호를 공식 LSW 다운로드 경로에서 받아 아래 판시사항에 넣었습니다. 본문의 빈칸 자체를 임의로 고치지는 않았습니다.**'
    if rid in ['C02','C11']:base+=' 본문이 가리키는 별지의 완전성은 별도로 확인해야 합니다. 누락된 별지 내용을 추정해 보충하지 않았습니다.'
    return base

def material_links(case):
    text=(BASE/'전문가 에이전트 정의 2.md').read_text()
    all_names=set(re.findall(r'^#### (.+)$',text,re.M))
    for name,_,_ in case['steps']:assert name in all_names,(case['id'],name)
    return all_names

manifest={'created_at':STAMP,'selection':'기존 24건 중 20건. C06·C13·C17·C20 제외. 분야를 고르게 포함하기 위한 선정이며 절대 난도 순위가 아님.','case_count':20,'autonomous_execution':'미실시','files':[]}
assert len(CASES)==20 and len({c['id'] for c in CASES})==20
names=[]
for i,c in enumerate(CASES,1):
    r=rows[c['id']]; names.append(f'{i:02d}_{slug(c["title"].split(" — ")[0])}_{slug(r["사건번호"])}.md')

for i,c in enumerate(CASES):
    r=rows[c['id']];sid,doc,raw=source_load(r);material_links(c)
    date=doc['선고일자']; pretty=f'{date[:4]}-{date[4:6]}-{date[6:8]}'
    official=f'https://www.law.go.kr/LSW/precInfoP.do?precSeq={sid}'
    p=ROOT/names[i]
    nav='[전체 목록](00_먼저_보기.md)'
    if i:nav+=f' · [이전 판례]({link(names[i-1])})'
    if i+1<len(CASES):nav+=f' · [다음 판례]({link(names[i+1])})'
    out=[f'# {i+1:02d}. {c["title"]}',
         f'**{doc["법원명"]} {pretty} · {doc["사건번호"]} · {doc["판결유형"]}**',nav,
         '[쉬운 풀이](#easy) · [재료 적용](#materials) · [보완점](#improve) · [판례 원문 전체](#original)',
         '이 파일 하나에 설명과 원문이 모두 있습니다. **예(Yes)·아니오(No)**는 바로 앞 질문에 대한 답입니다. 자료가 부족하다는 이유로 법적 결론을 억지로 둘 중 하나로 정하지 않습니다.',
         '---','<a id="easy"></a>','## 1. 이 사건을 쉽게 이해하기',c['story'],
         '아래는 이 판결의 핵심 쟁점을 쉽게 푼 설명입니다. 모든 쟁점과 의견의 원문은 파일 뒤에 있습니다. 다른 시점의 사건에 그대로 적용해도 된다는 뜻은 아닙니다.']
    for j,(q,a,why) in enumerate(c['qa'],1):
        out += [f'### {j}. {q}', f'**{a}.** {why}']
    out += ['### 그래서 법원은 어떻게 끝냈나요?',c['result'],
            '**용어:** 상고기각은 대법원이 그 상고를 받아들이지 않았다는 뜻입니다. 파기환송은 앞선 판결을 깨고 다시 재판하도록 돌려보냈다는 뜻이며, 그 자체가 최종 승소나 외부 처리 완료는 아닙니다.',
            f'판단 근거: [이 파일의 판시사항·판결요지](#issues) · [주문과 판결 이유 전체](#fulltext) · [국가법령정보센터 공식 원문]({official})']
    if c['id']=='C15':
        out+=['2024년 후속 판단 근거도 이 파일 맨 아래에 전문으로 붙였습니다. [2020다247190](#supplement-600537) · [2023다302838](#supplement-600539). 선정 20건에 추가로 센 것이 아니라 이 사건 풀이의 참고자료입니다.']
    out += ['---','<a id="materials"></a>','## 2. 현재 79개 재료로 어떻게 다루나요?',
            '### 이 사건을 맡길 재료가 이미 있나요?',
            '**예.** 아래는 현재 정의에 있는 재료를 이 사건에 대입한 순서입니다. 이름이 있다는 것과 실제로 정확히 처리했다는 것은 다릅니다.',
            '| 순서 | 먼저 확인할 질문 | 예라면 | 아니오라면 | 맡는 재료 |',
            '|---|---|---|---|---|']
    for j,(name,task,output) in enumerate(c['steps'],1):
        out.append(f'| {j} | {question(task)} | {output}{object_particle(output)} 남기고 다음으로 갑니다. | 빠진 자료나 판단을 보완합니다. 그 부분은 확인됐다고 쓰지 않습니다. | **{name}** |')
    out += ['### 위 단계가 끝나면 이 사건을 해결했다고 말해도 되나요?',
            '**아니오.** 실제 결과를 검사하고 원문의 주문·이유와 맞춰야 합니다. 판결 내용을 설명한 것, 새 사건을 판단한 것, 소송이나 외부 처리를 끝낸 것은 각각 다릅니다.',
            '### 현재 에이전트가 이 사건을 끝까지 해결하는 시험도 통과했나요?',
            '**아니오.** 이번 작업은 판결문을 공개한 상태에서 현재 설계에 대입한 검토입니다. 실제 에이전트의 자율 실행 합격 기록은 아닙니다.']
    out += ['---','<a id="improve"></a>','## 3. 무엇을 보완해야 하나요?',
            '### 이 사건 때문에 새 재료를 추가해야 하나요?',
            '**아니오.** 이번 대입에서 79개 밖의 새 재료가 꼭 필요하다는 근거는 찾지 못했습니다.',
            '### 기존 재료에 법률 업무의 구체적인 내용을 채워야 하나요?',
            f'**예.** {c["fill"]}',
            '이는 모든 직무에 새 규칙을 추가하자는 뜻이 아닙니다. 기존 재료의 「이 직무에서 채울 것」을 이 사건에 맞춰 구체화하고 시험하자는 뜻입니다. 별도의 법률 구현을 전부 검사해 내용이 없다고 확정한 것은 아닙니다.',
            '### 설명·순서도·시험 조건도 맞춰야 하나요?',
            '**예.** 아래는 작성 시점에 보관한 정의에서 확인한 사항입니다. 실제 프로그램이 같은 오류를 냈다는 뜻은 아닙니다. 다른 곳에서 수정한 최신판에 그대로 남아 있다고 단정하지 않습니다.']
    for key in c['issues']:
        q,a,why,refs=ISSUES[key]
        out += [f'**{q} → {a}.** {why}']
    out += ['### 고친 뒤 어떤 입력으로 확인하나요?',
            f'**시험 입력:** {r["변형입력"]}',
            f'**기대할 반응:** {r["기대반응"]}',
            f'**이런 답이면 통과인가요? → 아니오.** {c["trap"]}',
            '**이 시험을 이미 돌려서 통과했나요? → 아니오.** 위 입력은 판례의 추가 사실이 아니라, 다시 시험할 때 넣을 가상 변경입니다. 실제 결과는 아직 측정하지 않았습니다.',
            '**이 20건만 반복하면 새 사건 처리 능력도 증명되나요? → 아니오.** 이미 읽은 판례는 개발·회귀 시험에 쓰고, 별도로 공개하지 않은 새 과제에서 정확성·사람의 도움·시간·비용을 평가해야 합니다.']
    out += ['---','<a id="original"></a>','## 4. 판례 원문 전체',original_note(c['id']),
            f'**사건명:** {doc["사건명"]}',f'**공식 출처:** [국가법령정보센터 판례 {sid}]({official})',
            '[판시사항](#issues) · [판결요지](#summary) · [참조조문](#statutes) · [참조판례](#references) · [판결 전문](#fulltext)',
            original_sections(doc)]
    if c['id']=='C24':
        out += ['표장 이미지 출처: [국가법령정보센터 첨부 파일 36958970](https://www.law.go.kr/LSW/flDownload.do?flSeq=36958970). 받은 BMP를 내용 변화 없이 PNG로 저장해 표시했습니다.']
    extras=[]
    if c['id']=='C15':
        for extra in ['600537','600539']:
            sp=ARCHIVE/'재현/원본'/f'{extra}.json.gz'; rawextra=gzip.decompress(sp.read_bytes());edoc=json.loads(rawextra)['PrecService'];shutil.copyfile(sp,RAW/sp.name)
            out += ['---',f'<a id="supplement-{extra}"></a>',f'## 후속 참고 원문 — {edoc["사건번호"]}',
                    f'대법원 2024-12-19 · {edoc["판결유형"]}. [공식 원문](https://www.law.go.kr/LSW/precInfoP.do?precSeq={extra})',
                    '선정 판례 수에 추가로 세지 않은 후속 참고 판결입니다. 보관된 원문의 다섯 필드를 생략 없이 실었습니다.',original_sections(edoc,f'{extra}-')]
            extras.append({'source_id':extra,'case_number':edoc['사건번호'],'raw_sha256':digest(rawextra)})
    refs=[]
    for key in c['issues']:
        for fn,ln in ISSUES[key][3]:
            item=f'[{fn}]({link(".검토_기준/"+fn)}) {ln:,}행'
            if item not in refs:refs.append(item)
    out += ['---','## 출처와 검토 범위',
            f'- 선정 번호: 기존 검토의 **{c["id"]}**. 이 폴더에서는 읽는 순서대로 {i+1:02d}번입니다.',
            f'- 원문: 사용자가 지정한 누리플렉스 판례 저장소에서 앞선 검토 때 보관한 JSON. [보관 원본]({link(".검토_기준/원본/"+sid+".json.gz")}).',
            f'- 정의 기준: **{STAMP}**에 복사한 정의 1·2와 재료 대응표. 기존 정의 파일은 수정하지 않았습니다.',
            '- 보완점 확인 위치: '+ ' / '.join(refs)+'.',
            '- 법률 풀이와 재료 적용표는 작성자의 설명입니다. 판결문의 원문과 구분해 읽습니다. 현재의 모든 후속 판례와 개정 법령을 망라한 법률 안내서는 아닙니다.',
            nav]
    p.write_text(finish_document(out))
    manifest['files'].append({'file':p.name,'review_id':c['id'],'case_number':doc['사건번호'],'source_id':sid,'source_path':r['원본경로'],'raw_sha256':digest(raw),'md_sha256':digest(p.read_bytes()),'supplemental_cases':extras,'issues':c['issues']})

index=['# 판례 20건 — 먼저 보기',
       '**판례마다 파일 하나입니다.** 각 파일에 쉬운 예·아니오 풀이, 현재 재료 적용, 보완점, 판결 원문 전체가 순서대로 들어 있습니다. 구역은 구분선으로 나눴습니다.',
       '앞서 검토한 24건 중 형사 5·행정 4·민사 5·가사 2·세무 2·특허/상표 2건을 골랐습니다. 분야를 고르게 담기 위해 C06·C13·C17·C20을 제외했으며, 난도 순위를 새로 매긴 것은 아닙니다.',
       '---','## 바로 열기','| 순서 | 판례 | 사건번호 |','|---|---|---|']
for i,(c,n) in enumerate(zip(CASES,names),1):index.append(f'| {i:02d} | [{c["title"]}]({link(n)}) | {rows[c["id"]]["사건번호"]} |')
index += ['---','## 먼저 궁금할 네 가지',
          '**1. 참고한 판례 원문 20건이 들어 있나요? → 예.** 보관 JSON에 있는 판결 전문까지 실었습니다. 통상임금 파일에는 앞서 함께 참고한 후속 판례 2건도 붙였습니다. 본 판례 20건과 후속 참고 2건을 구분합니다.',
          '**2. 현재 재료로 이 쟁점들을 다룰 수 있나요? → 예, 설계상 책임을 배정할 수 있습니다.** 현재 기준은 9개 계통·79개 재료입니다. 이 자료는 실제 자율 해결 성공을 입증한 성적표는 아닙니다.',
          '**3. 새 재료를 늘려야 하나요? → 아니오.** 이번 표본에서 새 재료가 반드시 필요하다는 근거는 찾지 못했습니다. 기존 재료의 일부 설명·시험 조건과 연결은 맞춰야 합니다.',
          '**4. 추가로 보완하고 시험해야 하나요? → 예.** 사건별 법률 내용을 채우고, 문서 불일치·입력 누락을 고친 뒤 실제 실행을 시험해야 합니다.',
          '---','## 공통으로 고칠 부분도 확인됐나요?', '**예.** 아래는 이 자료의 작성 시점에 확인한 내용입니다. 다른 곳에서 수정 중인 문서와 구분하려고 기준 사본을 보관했습니다.']
for key,(q,a,why,refs) in ISSUES.items():index += [f'### {q}',f'**{a}.** {why}']
index += ['---','## 읽을 때 한 가지만 구분해 주세요',
          '**아니오라는 답이 곧 패소라는 뜻인가요? → 아니오.** 바로 앞 질문에 대한 답일 뿐입니다. 자료 부족, 특정 쟁점의 판단, 사건 전체의 주문은 서로 다릅니다.',
          f'작성 기준 시점: **{STAMP}**. 숨김 폴더 `.검토_기준`에는 출처·원본 사본·변환 코드·검증 기록을 보관했습니다. 읽을 때는 위의 판례 파일만 열면 됩니다.']
(ROOT/'00_먼저_보기.md').write_text(finish_document(index))
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(f'판례 파일 {len(names)}개와 목록 1개 생성. 원문 {len(names)}건 + 후속 참고 2건.')
